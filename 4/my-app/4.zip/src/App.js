import './App.css';
import UsersPage from "./pages/usersPage/UsersPage";

function App() {
  return (
    <div className="App">
        <UsersPage/>
    </div>
  );
}

export default App;
