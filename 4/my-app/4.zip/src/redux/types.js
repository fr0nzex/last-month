export const types = {
    CHANGE_TEXT: "CHANGE_TEXT",
    USERS_INFO: "USERS_INFO",
    ONE_USER_INFO: "ONE_USER_INFO"
}